<template>
  <div>
    <layout></layout>
  </div>
</template>
<script setup>
import Layout from './components/Layout.vue';
</script>
